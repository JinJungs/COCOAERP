package kh.cocoa.statics;

public class DocumentConfigurator {
	public static int recordCountPerPage = 10;
	public static int naviCountPerPage = 10;
}
